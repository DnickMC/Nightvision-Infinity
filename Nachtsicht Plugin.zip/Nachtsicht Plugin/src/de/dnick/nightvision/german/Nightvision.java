package de.dnick.nightvision.german;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Nightvision implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
		if(command.getName().equalsIgnoreCase("nachtsicht")|command.getName().equalsIgnoreCase("nightvision")|command.getName().equalsIgnoreCase("ns")){
			if(sender instanceof Player) {
				Player p = (Player)sender;
				if(p.hasPermission("nightvision.use")) {
					if(args.length == 0) {
						if(!(p.hasPotionEffect(PotionEffectType.NIGHT_VISION))) {
							p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 9999999, 3));
							p.sendMessage(Main.prefix + "�2Du kannst jetzt Nachts besser sehen!");
							return true;
						} else {
							p.removePotionEffect(PotionEffectType.NIGHT_VISION);
							p.sendMessage(Main.prefix + "�2Du kannst jetzt Nachts schlechter sehen!");
							return true;
						}
					}
					if(args.length == 1) {
						if(p.hasPermission("nightvision.other")) {
							Player target = Bukkit.getPlayer(args[0]);
							if(target != null) {
								if(!(target.hasPotionEffect(PotionEffectType.NIGHT_VISION))) {
									target.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 9999999, 3));
									target.sendMessage(Main.prefix + "�2Du kannst jetzt Nachts besser sehen!");
									p.sendMessage(Main.prefix + "�f" + args[0] + "�2 kann jetzt Nachts besser sehen");
									return true;
								} else {
									target.removePotionEffect(PotionEffectType.NIGHT_VISION);
									target.sendMessage(Main.prefix + "�2Du kannst jetzt Nachts schlechter sehen!");
									p.sendMessage(Main.prefix + "�f" + args[0] + "�2 kann jetzt Nachts schlechter sehen");
									return true;
								}
							} else {
								p.sendMessage(Main.prefix + "�4 Der Spieler �2" + args[0] + "�4 ist nicht auf dem Server!");
							}
						} else {
							p.sendMessage(Main.prefix + "�4Du hast dazu keine Berechtigung! Permission: nightvision.other");
						}
						if(args.length >=2) {
						p.sendMessage(Main.prefix + "�4Du musst /nachtsicht [Spieler] eingeben!");
						}
					} else {
					p.sendMessage(Main.prefix + "�4Du hast dazu keine Berechtigung! Permission: nightvision.use");
					}
				}
			} else {
				sender.sendMessage(Main.prefix + "�4Du musst ein Spieler sein, um diesen Command zu nutzen!");
			}
		}
		return false;

	}
}