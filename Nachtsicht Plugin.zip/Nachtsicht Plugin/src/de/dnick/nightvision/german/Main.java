package de.dnick.nightvision.german;

import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin{
	public static String prefix = "�1�lNacht�f�lSicht �8|�7 ";
	private ConsoleCommandSender c = getServer().getConsoleSender();
	
	@Override
	public void onEnable(){
		c.sendMessage(Main.prefix + "�2 Das Plugin wurde aktiviert!");
		c.sendMessage(Main.prefix + "�2 Autor: DnickMC");
		this.getCommand("ns").setExecutor(new Nightvision());
		this.getCommand("nachtsicht").setExecutor(new Nightvision());
		this.getCommand("nightvision").setExecutor(new Nightvision());
	}

	@Override
	public void onDisable(){
		c.sendMessage(Main.prefix + "�2 Das Plugin wurde deaktiviert!");
	}
}
